export class Nudgerequest {
}
