import { NudgeRequest } from './nudge-request.model';

describe('NudgeRequest', () => {
  it('should create an instance', () => {
    expect(new NudgeRequest()).toBeTruthy();
  });
});
