export class NudgeRequest {
    workflow:String;
    due:String;
    tag:String;
    isActivity:boolean = false;
}
