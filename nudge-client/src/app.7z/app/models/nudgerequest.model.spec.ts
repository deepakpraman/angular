import { Nudgerequest } from './nudgerequest.model';

describe('Nudgerequest', () => {
  it('should create an instance', () => {
    expect(new Nudgerequest()).toBeTruthy();
  });
});
